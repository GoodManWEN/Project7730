from .faster import *

__doc__ = faster.__doc__
if hasattr(faster, "__all__"):
    __all__ = faster.__all__